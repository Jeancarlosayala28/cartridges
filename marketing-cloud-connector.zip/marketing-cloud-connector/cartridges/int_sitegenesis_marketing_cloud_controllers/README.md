# int_sitegenesis_marketing_cloud_controllers

This cartridge contains the code needed to modify the SiteGenesis controllers cartridge to work with the Marketing Cloud Connector.  This cartridge overrides the matching files in SiteGenesis, so it should appear ahead of your controller cartridge in the cartridge path. 