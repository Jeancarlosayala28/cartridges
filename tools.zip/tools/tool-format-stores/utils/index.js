export const createObject = (element) => {
  const days = [
    {
      label: "Lunes",
      value: "mon",
    },
    {
      label: "Martes",
      value: "tue",
    },
    {
      label: "Miercoles",
      value: "wed",
    },
    {
      label: "Jueves",
      value: "thu",
    },
    {
      label: "Viernes",
      value: "fri",
    },
    {
      label: "Sabado",
      value: "sat",
    },
    {
      label: "Domingo",
      value: "sun",
    },
  ];

  return {
    _attributes: { "store-id": element["id"] },
    name: { _text: element.name },
    address1: { _text: element.address1 },
    city: { _text: element.city },
    "postal-code": { _text: element["postal-code"] || "" },
    "state-code": { _text: element["state-code"] },
    "country-code": { _text: element["country-code"] },
    email: { _text: element.email },
    phone: { _text: element.phone || "" },
    "store-hours":
      "<table><tbody><tr class='days' day='mon'openHours='08'openMin='0'closeHours='21'closeMin='0'><td>Lunes</td><td>08:00</td><td>-</td><td>21:00</td></tr><tr class='days' day='tue'openHours='08'openMin='0'closeHours='21'closeMin='0'><td>Martes</td><td>08:00</td><td>-</td><td>21:00</td></tr><tr class='days' day='wed'openHours='08'openMin='0'closeHours='21'closeMin='0'><td>Miércoles</td><td>08:00</td><td>-</td><td>21:00</td></tr><tr class='days' day='thu'openHours='08'openMin='0'closeHours='21'closeMin='0'><td>Jueves</td><td>08:00</td><td>-</td><td>21:00</td></tr><tr class='days' day='fri'openHours='08'openMin='0'closeHours='21'closeMin='0'><td>Viernes</td><td>08:00</td><td>-</td><td>21:00</td></tr><tr class='days' day='sat'openHours='08'openMin='0'closeHours='21'closeMin='0'><td>Sábado</td><td>08:00</td><td>-</td><td>21:00</td></tr><tr class='days' day='sun'openHours='08'openMin='0'closeHours='21'closeMin='0'><td>Domingo</td><td>09:00</td><td>-</td><td>21:00</td></tr></tbody></table>",
    // image: { _text: "" },
    latitude: { _text: element.latitude },
    longitude: { _text: element.longitude },
    "inventory-list-id": { _text: "inventory_" + element["id"] },
    "store-locator-enabled-flag": { _text: "true" },
    "demandware-pos-enabled-flag": { _text: "false" },
    "pos-enabled-flag": { _text: "false" },
    "custom-attributes": {
      "custom-attribute": [
        {
          _attributes: {
            "attribute-id": "empresaId",
          },
          _text: element.Empresa,
        },
        {
          _attributes: {
            "attribute-id": "inventoryListId",
          },
          _text: "inventory_" + element["id"],
        },
        {
          _attributes: {
            "attribute-id": "countryCodeValue",
          },
          _text: element["country-code"],
        },
        {
          _attributes: {
            "attribute-id": "isShippingAvailable",
          },
          _text: element["Servicio a Domicilio"] ? "true" : "false",
        },
      ],
    },
    "store-hours": createSchedule(element, days),
  };
};

const createSchedule = (element, days) => {
  // console.log(day, element[day.label.toLowerCase()]);

  return {
    _attributes: {
      "xml:lang": "x-default",
    },
    _text: `&lt;table&gt;
    &lt;tbody&gt; 
    ${days.map((day) => {
      return createRoute(
        { dayLabel: day.label, dayValue: day.value },
        defragSchedule(element[day.label.toLowerCase()])
      );
    })}
    &lt;/tbody&gt;
    &lt;/table&gt;`,
  };
};

const defragSchedule = (value) => {
  const [open, closed] = value.replace(/ /g, "").split("-");

  const [openHour, openMin] = open.split(":");
  const [closedHour, closedMin] = closed.split(":");

  return {
    openStr: open,
    openHour,
    openMin,
    closedStr: closed,
    closedHour,
    closedMin,
  };
};

const createRoute = (
  { dayLabel, dayValue },
  { openStr, openHour, openMin, closedStr, closedHour, closedMin }
) => {
  return `&lt;tr class="days" day="${dayValue}" openHours="${openHour}" openMin="${openMin}" closeHours="${closedHour}" closeMin="${closedMin}"&gt;
      &lt;td&gt;${dayLabel}&lt;/td&gt;
    &lt;td&gt;${openStr}&lt;/td&gt;
      &lt;td&gt;-&lt;/td&gt;
      &lt;td&gt;${closedStr}&lt;/td&gt;
    &lt;/tr&gt;`;
};
