import xlsx from "xlsx";
import xml2js from "xml-js";
import fs from "fs";
import { createObject } from "./utils/index.js";

const app = () => {
  const file = xlsx.readFile("Sucursales Lety.xlsx");
  const data = xlsx.utils.sheet_to_json(file.Sheets[file.SheetNames[0]]);

  console.log(data.length);

  const elements = [];

  data.forEach((element) => {
    elements.push(createObject(element));
  });

  const obj = {
    _declaration: {
      _attributes: {
        version: "1.0",
        encoding: "UTF-8",
      },
    },
    stores: {
      _attributes: {
        xmlns: "http://www.demandware.com/xml/impex/store/2007-04-30",
      },
      store: elements,
    },
  };

  const xml = xml2js.json2xml(obj, {
    compact: true,
    ignoreComment: true,
    spaces: 4,
  });

  fs.writeFile("stores.xml", xml, (err) => {
    if (err) {
      console.log(err);
    } else {
      console.log("The file was saved!");
    }
  });
};

app();
