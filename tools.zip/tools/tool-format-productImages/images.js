import fetch from "node-fetch";
import fs from "fs/promises";

const uploadFile = async (path, { fileName, file }) => {
  const auth =
    "Basic " +
    new Buffer.from(
      `ojimenez@h-h.com.mx:6hH]uMi*r]Ie_NxAXoqZcvNx,G[PXiwjExZ!W/PH`
    ).toString("base64");

  const url = `https://bjgb-007.sandbox.us01.dx.commercecloud.salesforce.com/on/demandware.servlet/webdav/${path}/${fileName}`;

  const request = await fetch(url, {
    method: "PUT",
    body: file,
    headers: {
      Authorization: auth,
      "Content-Type": "image/jpg",
    },
  });

  return request.ok;
};

(async () => {
  let dir = "./images";

  const files = await fs.readdir(dir);

  for (let f of files) {
    let image = await fs.readFile(`${dir}/${f}`, "base64");

    let status = await uploadFile(
      "Sites/Catalogs/storefront-catalog-m-en/prueba/prueba",
      {
        fileName: f,
        file: image,
      }
    );
    console.log(status);
  }

  // let image = await fs.readFile(
  //   `./bad/casa-kame-de-dragon-ball_3840x2160_xtrafondos.com.jpg`,
  //   "utf8"
  // );
  // console.log(image);
  // // fs.writeFile("prueba.txt", image);
})();
