import xlsx from "xlsx";
import xml2js from "xml-js";
import fs from "fs";

(async () => {
  const file = xlsx.readFile("inputFile.xlsx");
  const data = xlsx.utils.sheet_to_json(file.Sheets[file.SheetNames[0]]);

  const orderedData = [];
  data.forEach((d) => {
    let exist = orderedData.find((od) => od.pId == d["product-id"]);
    if (exist) {
      exist.images.push({
        type: d["view-type"],
        path: d["path"],
      });
    } else {
      orderedData.push({
        pId: d["product-id"],
        images: [
          {
            type: d["view-type"],
            path: d["path"],
          },
        ],
      });
    }
  });

  const products = orderedData.map((od) => {
    let imgGroupElements = [];
    od.images.forEach((img) => {
      if (imgGroupElements == 0) {
        imgGroupElements.push({
          _attributes: {
            "view-type": img.type,
          },
          image: [{ _attributes: { path: img.path } }],
        });
      } else {
        let exist = imgGroupElements.find(
          (ige) => ige._attributes["view-type"] == img.type
        );
        if (exist) {
          exist.image.push({ _attributes: { path: img.path } });
        } else {
          imgGroupElements.push({
            _attributes: {
              "view-type": img.type,
            },
            image: [{ _attributes: { path: img.path } }],
          });
        }
      }
    });
    return {
      _attributes: { "product-id": od.pId },
      images: { "image-group": imgGroupElements },
    };
  });

  // console.log(orderedData[100]);

  const obj = {
    _declaration: {
      _attributes: {
        version: "1.0",
        encoding: "UTF-8",
      },
    },
    catalog: {
      _attributes: {
        xmlns: "http://www.demandware.com/xml/impex/catalog/2006-10-31",
        "catalog-id": "storefront-catalog-m-en",
      },
      product: products,
    },
  };

  const xml = xml2js.json2xml(obj, {
    compact: true,
    ignoreComment: true,
    spaces: 4,
  });

  fs.writeFile("outputFile.xml", xml, (err) => {
    if (err) {
      console.log(err);
    } else {
      console.log("The file was saved!");
    }
  });
})();
