'use strict';

var BaseShippingHelpers = {
    getShippingModels: function () {},
    selectShippingMethod: function () {},
    ensureShipmentHasMethod: function () {},
    getShipmentByUUID: function () {},
    getAddressFromRequest: function () {}
};

module.exports = BaseShippingHelpers;
