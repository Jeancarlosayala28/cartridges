'use strict';

function BaseFullProductModel() {
}

BaseFullProductModel.prototype = {
};

module.exports = BaseFullProductModel;
