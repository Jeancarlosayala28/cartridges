'use strict';

function BaseShippingModel() {}

module.exports = BaseShippingModel;
