'use strict';

/**
 * Init for the displayFormat radio button custom editor
 *
 * Initialises the custom attribute editor with server side information. This editor does not need any.
 */
module.exports.init = function () {};
