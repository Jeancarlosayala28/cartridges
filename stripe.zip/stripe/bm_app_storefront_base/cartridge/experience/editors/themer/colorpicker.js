
'use strict';
/**
 * Init for the color picker custom editor
 */
module.exports.init = function () {};
