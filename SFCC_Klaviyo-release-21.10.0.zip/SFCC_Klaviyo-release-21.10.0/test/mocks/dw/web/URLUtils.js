'use strict';

function https() {
  return ['https://klaviyo.com'];
}

module.exports = {
  https: https
};
