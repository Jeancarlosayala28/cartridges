# Klaviyo LINK Cartridge for B2C Commerce

This is the Salesforce Certified Commerce Cloud Cartridge to integrate Klaviyo.
