'use strict';

/* API Includes */
var logger = require('dw/system/Logger').getLogger('SiteMapTesting', 'site.map.test');
var ContentMgr = require('dw/content/ContentMgr');
var URLUtils = require('dw/web/URLUtils');
var File = require('dw/io/File');
var FileWriter = require('dw/io/FileWriter');
var XmlWriter = require('dw/io/XMLStreamWriter');
var Calendar = require('dw/util/Calendar');
var StringUtils = require('dw/util/StringUtils');
var SitemapMgr = require('dw/sitemap/SitemapMgr');
var System = require('dw/system/System');
var Site = require('dw/system/Site')

var PRIORITY = 1.0;
var CHANGE_FREQ = 'daily'
/**
 * Create dynamic sitemap
 */
function generateSitemap(params) {
    var curentSiteID = Site.getCurrent().getID();
    var contentLibrary = ContentMgr.getSiteLibrary();
    var onlineFolders = contentLibrary.getRoot().getOnlineSubFolders();
    var changeFreq = params.ChangeFreq || CHANGE_FREQ;
    var priority = params.Priority || PRIORITY;
    var currentTime = new Calendar();
    var timeString = StringUtils.formatCalendar(currentTime, "yyyy-MM-dd'T'HH:mm:ss+00:00");

    //Path for  custom file
    var workingPath = File.IMPEX + File.SEPARATOR + params.TargetFolder;
    var fileName = "custom-content_1.xml";
    try {
        (new File(workingPath).mkdirs());
        var file = new File(workingPath + fileName);
        var fileWriter = new FileWriter(file);

        //Create XML file
        var xsw = new XmlWriter(fileWriter);
        xsw.writeStartDocument();
        xsw.writeStartElement("urlset");

        //Adding XML Schema metatags
        xsw.writeAttribute("xmlns", "http://www.sitemaps.org/schemas/sitemap/0.9");
        xsw.writeAttribute("xmlns:image", "http://www.google.com/schemas/sitemap-image/1.1");
        xsw.writeAttribute("xmlns:xhtml", "http://www.w3.org/1999/xhtml");
        xsw.writeAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
        xsw.writeAttribute("xsi:schemaLocation", "http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd http://www.google.com/schemas/sitemap-image/1.1 http://www.google.com/schemas/sitemap-image/1.1/sitemap-image.xsd http://www.w3.org/1999/xhtml http://www.w3.org/2002/08/xhtml/xhtml1-strict.xsd");

        for (let i = 0; i < onlineFolders.length; i++) {
            var folder = onlineFolders[i];
            var onlineContent = folder.getOnlineContent();

            //Looping content to get content-Assets urls and adding in custom xml file
            for (let j = 0; j < onlineContent.length; j++) {
                var contentAsset = onlineContent[j];
                if(contentAsset && 'custom' in contentAsset && !empty(contentAsset.custom.includeInCustomSitemap) && contentAsset.custom.includeInCustomSitemap) {
                    var url = getBlogDetailURL(contentAsset.custom.blogType.displayValue, contentAsset.ID);
                    xsw.writeStartElement("url");
                    xsw.writeStartElement("loc");
                    xsw.writeCharacters(url);
                    xsw.writeEndElement();
                    xsw.writeStartElement("lastmod");
                    xsw.writeCharacters(timeString);
                    xsw.writeEndElement();
                    xsw.writeStartElement("changefreq");
                    xsw.writeCharacters(changeFreq);
                    xsw.writeEndElement();
                    xsw.writeStartElement("priority");
                    xsw.writeCharacters(priority);
                    xsw.writeEndElement();
                    xsw.writeEndElement();	
                }
            }
        }
        xsw.writeEndElement();
        xsw.writeEndDocument();

        xsw.close();
        fileWriter.close();

        //Move the file to custom-sitemap shared directory
        var hostName = getHostName(curentSiteID);
        SitemapMgr.addCustomSitemapFile(hostName, file);
    } catch (e) {
        logger.error('Issue with creating custom sitemap' + JSON.stringify(e));
    }
}

function getBlogDetailURL(type, cid) {
    var URL = URLUtils.https('Page-Show', 'cid', cid).toString();

    if (System.getInstanceType() == System.PRODUCTION_SYSTEM) {
        var hostname = Site.getCurrent().getCustomPreferenceValue('domainName');
        if (URL.search(hostname) == -1) {
            logger.error("Creating custom url and system url is : "+URL);
            var folder = '', protocol = 'https://', extension = '.html';
            if (type == 'articles' || type == 'Articles' || type == 'article' || type == 'Article')
                folder = 'articles';
            if (type == 'videos' || type == 'Videos' || type == 'video' || type == 'Video')
                folder = 'videos';
            if (type == 'podcasts' || type == 'Podcasts' || type == 'podcast' || type == 'Podcast')
                folder = 'podcasts';
            URL = protocol + hostname + File.SEPARATOR + folder + File.SEPARATOR + cid + extension;
        }
    }

    return URL;
}

function getHostName(siteId) {
    var hostname = '';
    if (System.getInstanceType() == System.PRODUCTION_SYSTEM) {
        hostname = Site.getCurrent().getCustomPreferenceValue('domainName');
    } else {
        hostname = System.getInstanceHostname() + '/on/demandware.store/Sites-' + siteId + '-Site/default/';
    }
    return hostname.toLowerCase();
}

module.exports = {
    GenerateSitemap: generateSitemap
}